var ismenushowing;
var istexttoolboxactive=false;
var ismousedown,islayermousedown,isdialogmousedown,iscanvasmousedown;
var xpos,ypos;
var xposmove,yposmove;
var DocumentsLayerCount=[];
var Documentsheight=[],Documentswidth=[],Documentsdpi=[];
var documentsccount;
var actualdoccount;
var currentdocument;
var isspacebardown;
var isctrldown;
var isdialogshowing;
var iscanvasmoved;
var imgxpos,imgypos;
var isdocumentsaved=[];
var currenttool;
var currentlayer;
var cancallpreview=0;
var timerID; 
var tempcanvas="",templayer="";
var imagepreview=document.createElement("canvas");

//document.addEventListener("contextmenu",(e)=>{e.preventDefault();});
timerID=setInterval(() => {
    if(actualdoccount>0 && cancallpreview>0){
        drawpreview();
        if(cancallpreview>0)
            cancallpreview-=1;
    }}, 50);

initialise();
createdocument();
function initialise(){
    ismenushowing=false;
    ismousedown=false;
    xpos=0,ypos=0;
    xposmove=0,yposmove=0;
    DocumentsLayerCount=[];
    documentsccount=0;
    actualdoccount=0;
    currentdocument=-1;
    isspacebardown=false;
    isctrldown=false;
    isdialogshowing=false;
    imgxpos=0,imgypos=0;
    isdocumentsaved=[];
    currenttool="tshape";//"tmove";
    //setting font font and font size=16 as default size for text area 
    document.getElementById("texttool").style.fontFamily=document.getElementById("texttooloptionsfont").value;
    document.getElementById("texttool").style.fontSize=document.getElementById("texttooloptionsfsizetext").value+"px";
    defaultcolor();
    activatetool(currenttool);
    document.addEventListener("keydown",function(event){keydown(event);});
    document.addEventListener("keyup",function(){keyup();});
    document.addEventListener("mouseup",function(){
    ismousedown=false;isdialogmousedown=false;islayermousedown=false;iscanvasmousedown=false;tempcanvas="";templayer="";if(currentlayer!="none")cancallpreview=3;
    });
    document.addEventListener("mousemove",function(event){mousemovenew(event);})

    window.onclick = function(event) {
        if (!event.target.matches('.dropmenu')) {
            hidemenu()
        }
        console.log(event.target)
        if(currenttool==="tdrop" && !(event.target.matches('.tls1')||event.target.matches('.tlsimg'))){
        activatetool("tmove");
        }
    }
}
function mousemovenew(event){
    if(ismousedown && !isspacebardown){
            //from canvass
            isdocumentsaved[currentdocument]=false;
            //var y=event.clientY-imgypos;
            //moving objects
        if(currenttool==="tmove"){
            iscanvasmoved=true;
            layers=getselectedlayers();
            if(layers[layers.length-1]==="allselected") layers.pop();
            if(layers.length===1){
                
            document.getElementById(currentlayer).style.top=event.screenY-yposmove+"px";
            document.getElementById(currentlayer).style.left=event.screenX-xposmove+"px";
            }else{
                var x=event.screenX-xposmove,y=event.screenY-yposmove;
                x-=document.getElementById(tempcanvas).style.left.slice(0,document.getElementById(tempcanvas).style.left.length-2)*1;
                y=y-document.getElementById(tempcanvas).style.top.slice(0,document.getElementById(tempcanvas).style.top.length-2)*1;
                
                for(var a=0;a<layers.length;a++){
                    document.getElementById("D"+layers[a]).style.top=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1+y+"px";
                    document.getElementById("D"+layers[a]).style.left=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1+x+"px";
                }
            }
        }else if(currenttool==="tshape"){
                if(!ismultilayerselected() && islayereditable(currentlayer.slice(1,currentlayer.length))){
                const ctx = document.getElementById("drawingcanvas").getContext("2d");
                ctx.clearRect(0,0,Documentswidth[currentdocument],Documentsheight[currentdocument]);
                ctx.fillStyle = document.getElementById("colorf").style.backgroundColor;
                ctx.fillRect(imgxpos, imgypos, event.layerX-imgxpos, event.layerY-imgypos);
                
                const ctx1=imagepreview.getContext("2d");
                ctx1.clearRect(0,0,Documentswidth[currentdocument],Documentsheight[currentdocument]);
                ctx1.fillStyle = document.getElementById("colorf").style.backgroundColor;
                ctx1.fillRect(imgxpos, imgypos, event.layerX-imgxpos, event.layerY-imgypos);
            document.getElementById("testmessage").innerText="x="+imgxpos+":y:"+imgypos+"w="+(event.layerX-imgxpos)+":h="+(event.layerY-imgypos);
                document.getElementById(currentlayer).src=imagepreview.toDataURL("image/png");
            }else showmessage("Select a layer to draw.")
        }
    }else{
            if(currenttool==="tdrop" || currenttool==="tbucket"){
                if(document.getElementById("cursor").classList.contains("hide")) document.getElementById("cursor").classList.remove("hide");
                document.getElementById("cursor").style.top=event.pageY-document.getElementById("cursor").offsetHeight+"px";
                document.getElementById("cursor").style.left=event.pageX+"px";
                if(currenttool==="tdrop" && event.target.matches(".canvass")){
                }
            }
    }
}
function pagemousedown(event,object){
    xpos=event.screenX-document.getElementById(object).style.left.slice(0,document.getElementById(object).style.left.length-2);
    ypos=event.screenY-document.getElementById(object).style.top.slice(0,document.getElementById(object).style.top.length-2);
    if(currenttool==="ttext" && document.getElementById("texttooldiv").classList.contains("hide")){
        ismousedown=false;
        istexttoolboxactive=true;
        document.getElementById("texttool").style.top=event.pageY+"px";
        document.getElementById("texttool").style.left=event.pageX+"px";
        document.getElementById("drawingcanvas").style.top=event.pageY+"px"; document.getElementById("drawingcanvas").style.left=event.pageX+"px";
        document.getElementById("texttooldiv").classList.remove("hide");
        document.getElementById("drawtextcheckmark").classList.remove("hide");
        changetextfont();
        document.getElementById("texttool").value="";
    }else if(currenttool==="tshape"){
        imgxpos=event.layerX;
        console.log(event)
        imgypos=event.layerX;
        document.getElementById("drawingcanvas").height=Documentsheight[currentdocument]*1+100;
        document.getElementById("drawingcanvas").width=Documentswidth[currentdocument]*1+100;
        imagepreview.height=Documentsheight[currentdocument]*1+100;
        imagepreview.width=Documentswidth[currentdocument]*1+100;
        document.getElementById("drawingcanvasdiv").style.top=document.getElementById("doc"+currentdocument).offsetTop+"px";
        document.getElementById("drawingcanvasdiv").style.left=document.getElementById("doc"+currentdocument).offsetLeft+"px";
        if(!ismultilayerselected() && islayereditable(currentlayer.slice(1,currentlayer.length))){
            document.getElementById(currentlayer).src=document.getElementById("drawingcanvas").toDataURL("image/png");
            document.getElementById(currentlayer).height=document.getElementById("drawingcanvas").height;document.getElementById(currentlayer).width=document.getElementById("drawingcanvas").width;
            document.getElementById(currentlayer).style.left="0px";document.getElementById(currentlayer).style.top="0px";
        }
        ismousedown=true;
    }else if(currenttool==="tmove" && !iscanvasmousedown){
        deselectlayers();
        currentlayer="none";
    }
    else ismousedown=true;
    if(isspacebardown){document.getElementById(object).style.cursor="grabbing"; ismousedown=true;}
}
// MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!! 
// MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!! 
// MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!! 
// MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!!  MENU OPTION FUNCTIONS START !!! 

function menushow(menu){
    ismenushowing=true;
    document.getElementById(menu).classList.remove("hide");
}
function menuhovershow(menu){
    if(ismenushowing===true){
        hidemenu(); ismenushowing=true;
        document.getElementById(menu).classList.remove("hide");
    }
}
function hidemenu(){
    var dropdowns = document.getElementsByClassName("menuitems-hide");
    for (var i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (!openDropdown.classList.contains('hide')) {
        openDropdown.classList.add('hide');
        ismenushowing=false;
      }
    }
}
function showopen(){document.getElementById("fileopen").click();}

function showdialog(dialog){
    isdialogshowing=true;
    if(dialog==="saveas"){
        if(window.innerHeight>window.innerWidth){
            document.getElementById("saveasdialog").style.width="90vw";
            document.getElementById("saveasdialog").style.height="90vw";
            var int=document.getElementById("doc"+currentdocument).offsetHeight/document.getElementById("doc"+currentdocument).offsetWidth;
            //stretch background image to max height & width
            //document.getElementById("savejpg").style.backgroundSize=document.getElementById("doc"+currentdocument).offsetHeight+"px "+document.getElementById("doc"+currentdocument).offsetHeight+"px";
            if(int===1){
                document.getElementById("savejpg").style.height=window.innerWidth*44/100+"px";
                document.getElementById("savejpg").style.width=window.innerWidth*44/100+"px";
            }else if(int>1){
                document.getElementById("savejpg").style.width=window.innerWidth*44/100+"px";
                document.getElementById("savejpg").style.height=document.getElementById("savejpg").offsetWidth*int+"px";
            }else{
                document.getElementById("savejpg").style.width=window.innerWidth*44/100+"px";
                document.getElementById("savejpg").style.height=document.getElementById("savejpg").offsetWidth*int+"px";
            } 
        }else{
            //stretch background image to max height & width
            //document.getElementById("savejpg").style.backgroundSize=document.getElementById("doc"+currentdocument).offsetHeight+"px "+document.getElementById("doc"+currentdocument).offsetHeight+"px";
            document.getElementById("saveasdialog").style.width="90vh";
            document.getElementById("saveasdialog").style.width="80vh";
            var int=document.getElementById("doc"+currentdocument).offsetHeight/document.getElementById("doc"+currentdocument).offsetWidth;
            if(int===1){
                document.getElementById("savejpg").style.height=window.innerHeight*44/100+"px";
                document.getElementById("savejpg").style.width=window.innerHeight*44/100+"px";
            }else if(int>1){
                document.getElementById("savejpg").style.width=window.innerHeight*44/100+"px";
                document.getElementById("savejpg").style.height=document.getElementById("savejpg").offsetWidth*int+"px";
            }else{
                document.getElementById("savejpg").style.width=window.innerHeight*44/100+"px";
                document.getElementById("savejpg").style.height=document.getElementById("savejpg").offsetWidth*int+"px";
            }
        }
        previewjpg();
    }
    document.getElementById(dialog).classList.remove("hide");
}
function hidedialog(dialog){
    isdialogshowing=false; document.getElementById(dialog).classList.add("hide");
}
function togglefullscreen(){
    if(document.getElementById("fullscreen").src.toString().includes("expand.svg")){
        document.documentElement.requestFullscreen();
        document.getElementById("fullscreen").src="./public/img/contract-outline.svg";
    }else{
        document.exitFullscreen();
        document.getElementById("fullscreen").src="./public/img/expand.svg";
    }
}
// MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!! 
// MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!! 
// MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!! 
// MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!!  MENU OPTION FUNCTIONS END !!! 

function mousedown(event){ xpos=event.layerX; ypos=event.layerY; isdialogmousedown=true; }
function mousemove(event,dialogbox){
    if(isdialogmousedown){ var y=event.clientY-ypos; if(y<0)y=0;
        document.getElementById(dialogbox).style.top=y+"px";
        document.getElementById(dialogbox).style.left=event.clientX-xpos+"px";
    }
}
function canvasmouseup(event,object){
    if(currenttool==="tmove" && !iscanvasmoved){
        if(isctrldown){
            if(!document.getElementById("layer"+object.slice(1,object.length)).classList.contains("activelayer")){
            currentlayer=object;
            selectlayer(object.slice(1,object.length));
            }else if(ismultilayerselected()){
                document.getElementById("layer"+object.slice(1,object.length)).classList.remove("activelayer");
            }
        }else {selectlayer(object.slice(1,object.length)); currentlayer=object;}
    }
}
function canvasmousedown(event,object){ iscanvasmousedown=true;
    xposmove=event.screenX-document.getElementById(object).offsetLeft;
    yposmove=event.screenY-document.getElementById(object).offsetTop;
    if(currenttool==="tmove" && iscanvasmousedown){settempcanvas(object); iscanvasmoved=false;}
}
function canvasmousemove(event,object){
    if(currenttool==="tmove"){ var layer=object.slice(1,object.length);
        if(!document.getElementById("layer"+layer).classList.contains("activelayer") && tempcanvas===object && ismousedown){
        currentlayer=object; selectlayer(layer);}
    }
}
function pagemousemove(event,canvas){
    var object="doc"+currentdocument;
    if(ismousedown){
        if(isspacebardown){
            var y=event.screenY-ypos;
            var x=event.screenX-xpos;
            //if project window goes off bound retain 10% of its height/width within working space area **if it goes negative
            if(x<(-document.getElementById(object).offsetWidth+(document.getElementById(object).offsetWidth*10/100))) x=-document.getElementById(object).offsetWidth+document.getElementById(object).offsetWidth*10/100;
            if(y<(-document.getElementById(object).offsetHeight+(document.getElementById(object).offsetHeight*10/100))) y=-document.getElementById(object).offsetHeight+document.getElementById(object).offsetHeight*10/100;
            //**if it goes positive
            //if(x>(document.getElementById(object).offsetWidth+(document.getElementById(object).offsetWidth*90/100))) x=document.getElementById(object).offsetWidth+document.getElementById(object).offsetWidth*90/100;
            //if(y>(document.getElementById(object).offsetHeight+(document.getElementById(object).offsetHeight*90/100))) y=document.getElementById(object).offsetHeight+document.getElementById(object).offsetHeight*90/100;
        
            document.getElementById(object).style.top=y+"px";
            document.getElementById(object).style.left=x+"px";
        }
    }
}
function pagemouseup(){
    if(isspacebardown) document.getElementById("doc"+currentdocument).style.cursor="grab";
    if(currenttool==="ttext") document.getElementById("texttool").focus();
    else if(currenttool==="tshape" && !ismultilayerselected() && islayereditable(currentlayer.slice(1,currentlayer.length))){
        //drawing objects
        //trimimage();
        //document.getElementById(currentlayer).src=imagepreview.toDataURL();
        trimimage1(currentlayer);
    }
}
function swapheightwidth(){
    var a=document.getElementById("newheight").value;
    document.getElementById("newheight").value=document.getElementById("newwidth").value;
    document.getElementById("newwidth").value=a;
}
function validatenumber(element,defaultvalue){ if(!(document.getElementById(element).value*1)>=1) document.getElementById(element).value=defaultvalue*1; }
function drawpreview(){
try{
    if(!ismultilayerselected() && !islayerhidden(currentlayer.slice(1,currentlayer.length))){
    const canvas1=document.createElement("canvas");
    canvas1.height=document.getElementById("doc"+currentdocument).offsetHeight;
    canvas1.width=document.getElementById("doc"+currentdocument).offsetWidth;
    const ctx1=canvas1.getContext("2d");
    const img=document.getElementById(currentlayer);
    ctx1.drawImage(img,0,0,img.width,img.height,img.offsetLeft,img.offsetTop,img.width,img.height);
    const img1=new Image();
    img1.src=canvas1.toDataURL("image/png");
    
    const canvas2=document.createElement("canvas");
    const ctx2=canvas2.getContext("2d");
    canvas2.height=document.getElementById("preview"+currentlayer.slice(1,currentlayer.length)).offsetHeight;
    canvas2.width=document.getElementById("preview"+currentlayer.slice(1,currentlayer.length)).offsetWidth;
    ctx2.drawImage(img1,0,0,canvas1.width,canvas1.height,0,0,canvas2.width,canvas2.height);
    const img2=new Image();
    img2.src=canvas2.toDataURL("image/png");

    document.getElementById("preview"+currentlayer.slice(1,currentlayer.length)).src=img2.src;
    }
    }catch(err){console.error("Error from Drawpreview() function:"+err);}
}
function previewjpg(){
    const canvas=document.createElement("canvas");
    canvas.height=document.getElementById("doc"+currentdocument).offsetHeight;
    canvas.width=document.getElementById("doc"+currentdocument).offsetWidth;
    //console.log(canvas.height+":"+canvas.width)
    const ctx=canvas.getContext("2d");
    var imageData=ctx.getImageData(0,0,canvas.width,canvas.height);
    
        const documentcurrent=document.getElementById("doc"+currentdocument).childNodes;
        for(var a=0;a<documentcurrent.length;a++){
        if(!islayerhidden(documentcurrent[a].id.slice(1,documentcurrent[a].id.length))){
            var tmpcanvas=documentcurrent[a];
            ctx.drawImage(tmpcanvas,0,0,tmpcanvas.width,tmpcanvas.height,tmpcanvas.offsetLeft,tmpcanvas.offsetTop,tmpcanvas.width,tmpcanvas.height);

            const tmpimagedata=ctx.getImageData(0,0,canvas.width,canvas.height);
            for(var m=0;m<imageData.data.length;m+=4){
                if(tmpimagedata.data[m+3]===255 || imageData.data[m+3]===0){
                    imageData.data[m]=tmpimagedata.data[m];
                    imageData.data[m+1]=tmpimagedata.data[m+1];
                    imageData.data[m+2]=tmpimagedata.data[m+2];
                    imageData.data[m+3]=tmpimagedata.data[m+3];
                }else if(tmpimagedata.data[m+3]>0){
                    var tmpint=tmpimagedata.data[m+3]/255;
                    imageData.data[m]+=(tmpimagedata.data[m]-imageData.data[m])*tmpint;
                    imageData.data[m+1]+=(tmpimagedata.data[m+1]-imageData.data[m+1])*tmpint;
                    imageData.data[m+2]+=(tmpimagedata.data[m+2]-imageData.data[m+2])*tmpint;
                }
            }
        }
    }
    ctx.putImageData(imageData,0,0);
    var data=canvas.toDataURL("image/jpeg",document.getElementById("saveasjpgslider").value*1/100);
    document.getElementById("savejpg").src=data;//style.backgroundImage="url('"+data+"')";
    
    canvas.toBlob((blob) =>{
        var size=blob.size/1024;
        if(size>1024){
            size=size/1024;
            var sizestring=Math.floor(size).toString()+".";
            if(size.toString().slice(sizestring.length,sizestring.length+2)==="") sizestring+="0";
            else sizestring+=size.toString().slice(sizestring.length,sizestring.length+2);
            document.getElementById("previewjpgfs").innerText="File Size: "+Math.floor(size/1024)+(size/1024).toString((size/1024).toString().indexOf('.')+1,(size/1024).toString().length)+" MB";
        }
        else {
            var sizestring=Math.floor(size).toString()+".";
            if(size.toString().slice(sizestring.length,sizestring.length+2)==="") sizestring+="0";
            else sizestring+=size.toString().slice(sizestring.length,sizestring.length+2);
            document.getElementById("previewjpgfs").innerText="File Size: "+sizestring+" KB";
        }
    },'image/jpeg',document.getElementById("saveasjpgslider").value*1/100);
    
}
function savejpg(){
    save("jpeg",document.getElementById("saveasjpgslider").value*1/100,document.getElementById("jpgname").value);
    document.getElementById("saveas").classList.add("hide");
}
function showsliderpercent(sliderid){
    document.getElementById(sliderid+"pc").innerText= document.getElementById(sliderid).value+"%";
}
function createdocument(){
    hidedialog('new');
    var height=width=500;
    var top,left;
    top=document.getElementById("projects").offsetHeight/2-height/2;
    left=document.getElementById("projects").offsetWidth/2-width/2;
    var tmpstring=documentsccount;
    document.getElementById("projecttitle").innerHTML=document.getElementById("projecttitle").innerHTML+"<div id='title"+documentsccount+"' class='documenttitle' onclick='showdocument("+tmpstring+")'><div style='overflow:hidden;text-wrap:nowrap;'>&nbsp;New Project</div><div class='closebtn'><a onclick='checksaved("+tmpstring+")'>X</a></div></div>";
    tmpstring="'"+"D"+documentsccount+"1"+"'";
    document.getElementById("projects").innerHTML=document.getElementById("projects").innerHTML+"<div id='doc"+documentsccount+"' class='document1' style='clip-path:inset(0px);width:500px;height:500px;top:"+top+"px;left:"+left+"px' onmouseup='pagemouseup()' onmousedown="+String.fromCharCode(34)+"pagemousedown(event,'doc"+documentsccount+"')"+String.fromCharCode(34)+"><img draggable='false' class='canvass' id='D"+documentsccount+"1' height='"+height+"' width='"+width+"' onmousemove="+String.fromCharCode(34)+"canvasmousemove(event,"+tmpstring+")"+String.fromCharCode(34)+" onmouseup="+String.fromCharCode(34)+"canvasmouseup(event,"+tmpstring+")"+String.fromCharCode(34)+" onmousedown="+String.fromCharCode(34)+"canvasmousedown(event,"+tmpstring+")"+String.fromCharCode(34)+"/></div>";
    document.getElementById("layerbox").innerHTML+="<div id='layerbox"+documentsccount+"'><div id='layerdock"+documentsccount+"' class='layerbox'><div id='layer"+documentsccount+"1' class='layer activelayer layerdrag' draggable='true' ondragleave='layerdragleave(event)' ondragover='layerdragover(event)' ondragstart='layerdragstart(event)' ondrop='layerdrop(event)'><div><img id='eye"+documentsccount+"1' src='./public/img/eye.svg' onclick="+String.fromCharCode(34)+"hidelayer('"+documentsccount+"1')"+String.fromCharCode(34)+" class='layereye layerdrag'></div><div><img id='preview"+documentsccount+"1' src='' class='layerpreview layerdrag'></div><div id='name"+documentsccount+"1' class='layername layerdrag' onmousemove="+String.fromCharCode(34)+"activatelayer('"+documentsccount+"1')"+String.fromCharCode(34)+" onmousedown="+String.fromCharCode(34)+"settemplayer('"+documentsccount+"1')"+String.fromCharCode(34)+" onmouseup="+String.fromCharCode(34)+"selectlayer('"+documentsccount+"1')"+String.fromCharCode(34)+">Layer 1</div></div></div></div>";
    Documentsheight.push(document.getElementById("newheight").value);
    Documentswidth.push(document.getElementById("newwidth").value);
    Documentsdpi.push(document.getElementById("newdpi").value);
    DocumentsLayerCount.push(1);
    currentlayer="D"+documentsccount+"1"; document.getElementById(currentlayer).src=document.getElementById("drawingcanvas").toDataURL("image/png");
    actualdoccount+=1;
    isdocumentsaved.push(false);
    currentdocument=documentsccount;
    documentsccount+=1;
    hidedialog("new");
    showdocument(currentdocument);
}
function openfile(){
    console.log(document.getElementById("fileopen").files[0])
    //console.log(document.getElementById("fileopen").files[1])
    document.getElementById("fullscreen").src=URL.createObjectURL(document.getElementById("fileopen").files[0]);

}
function save(filetype,percent,filename){
    isdocumentsaved[currentdocument]=true;
    //var img=new Image();
    //var imagefile=document.getElementById("D"+currentdocument+""+1).toDataURL('image/jpeg',1);// high quality ('image/jpeg',0.5);//medium quality
    //var imagefile3=document.getElementById("D"+currentdocument+""+1).toDataURL('image/jpeg',0.1);// low quality
    //img.src=imagefile; document.getElementById("tmpimg").style.backgroundImage="url('"+imagefile+"')";
    //document.getElementById("tmpimg1").src=img.src;
    const canvas=document.createElement("canvas");
    canvas.height=document.getElementById("doc"+currentdocument).offsetHeight;
    canvas.width=document.getElementById("doc"+currentdocument).offsetWidth;
    //console.log(canvas.height+":"+canvas.width)
    const ctx=canvas.getContext("2d");
    var imageData=ctx.getImageData(0,0,canvas.width,canvas.height);

    const documentcurrent=document.getElementById("doc"+currentdocument).childNodes;
    for(var a=0;a<documentcurrent.length;a++){
    if(!islayerhidden(documentcurrent[a].id.slice(1,documentcurrent[a].id.length))){
        var tmpcanvas=documentcurrent[a];
        ctx.drawImage(tmpcanvas,0,0,tmpcanvas.width,tmpcanvas.height,tmpcanvas.offsetLeft,tmpcanvas.offsetTop,tmpcanvas.width,tmpcanvas.height);

        const tmpimagedata=ctx.getImageData(0,0,canvas.width,canvas.height);
            for(var m=0;m<imageData.data.length;m+=4){
                if(tmpimagedata.data[m+3]===255 || imageData.data[m+3]===0){
                    imageData.data[m]=tmpimagedata.data[m];
                    imageData.data[m+1]=tmpimagedata.data[m+1];
                    imageData.data[m+2]=tmpimagedata.data[m+2];
                    imageData.data[m+3]=tmpimagedata.data[m+3];
                }else if(tmpimagedata.data[m+3]>0){
                    var tmpint=tmpimagedata.data[m+3]/255;
                    imageData.data[m]+=(tmpimagedata.data[m]-imageData.data[m])*tmpint;
                    imageData.data[m+1]+=(tmpimagedata.data[m+1]-imageData.data[m+1])*tmpint;
                    imageData.data[m+2]+=(tmpimagedata.data[m+2]-imageData.data[m+2])*tmpint;
                }
            }
        }
    }
    ctx.putImageData(imageData,0,0);
    canvas.toBlob((blob) =>{
        const url=URL.createObjectURL(blob);
        const download=document.createElement("a");
        download.href=url;
        if(filetype==="jpeg") download.download=filename+".jpg";
        else download.download=filename+"."+filetype;
        download.click();
    },'image/'+filetype,percent);
    //console.log(atob(imagefile.slice(22,imagefile.length)));
}
function closedocument(){
    actualdoccount-=1;
    document.getElementById("closingdocument").classList.add("hide");

    document.getElementById("title"+currentdocument).remove();
    document.getElementById("doc"+currentdocument).remove();
    document.getElementById("layerbox"+currentdocument).remove();

    if(actualdoccount>0){
        DocumentsLayerCount[currentdocument]=0;
        for(var a=0;a<DocumentsLayerCount.length;a++){
            if(DocumentsLayerCount[a]>0){
                currentdocument=a;
                showdocument(a);
                break;
            }
        }
    }else{
        initialise();
    }
}
function saveandclose(){
    save(); closedocument();    
}
function checksaved(doc){
    if(isdocumentsaved[doc]){ closedocument();
    }else{ document.getElementById("closingdocument").classList.remove("hide"); }
}
function showdocument(doc){
    currentdocument=doc;
    /*const documentcurrent=document.getElementById("projecttitle").childNodes;
    console.log(documentcurrent[0]+documentcurrent.length)
    for(var a=0;a<documentcurrent.length;a++){
            documentcurrent[a].classList.remove("titleborder");
            document.getElementById("doc"+documentcurrent[a].id.slice(5,documentcurrent[a].id.length)).classList.add("hide");
            document.getElementById("layerbox"+documentcurrent[a].id.slice(5,documentcurrent[a].id.length)).classList.add("hide");
        }*/
    for(var a=0;a<DocumentsLayerCount.length;a++){
        if(DocumentsLayerCount[a]>0){
            document.getElementById("title"+a).classList.remove("titleborder");
            document.getElementById("doc"+a).classList.add("hide");
            document.getElementById("layerbox"+a).classList.add("hide");
        }
    }
    document.getElementById("title"+doc).classList.add("titleborder");
    document.getElementById("doc"+doc).classList.remove("hide");
    document.getElementById("layerbox"+doc).classList.remove("hide");
    currentlayer=getcurrentlayer();
}

//^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START
//^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START
//^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START
//^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START^^^^ TOOLS FUNCTIONS START
// MOVE TOOL FUNCTIONS //
function alignlayershorizontal(align){
    if(ismultilayerselected()){    
        if(align==="right"){
            var layers=getselectedlayers(),temp,right=document.getElementById("D"+layers[0]).style.left.slice(0,document.getElementById("D"+layers[0]).style.left.length-2)*1+document.getElementById("D"+layers[0]).width;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1+document.getElementById("D"+layers[a]).width;
                if(temp>right)right=temp;
             }
             for(var a=0;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.left=right-document.getElementById("D"+layers[a]).width+"px";
             }
        }else if(align==="center"){
            var layers=getselectedlayers(),temp;
            var right=document.getElementById("D"+layers[0]).style.left.slice(0,document.getElementById("D"+layers[0]).style.left.length-2)*1+document.getElementById("D"+layers[0]).width;
            var left=document.getElementById("D"+layers[0]).style.left.slice(0,document.getElementById("D"+layers[0]).style.left.length-2)*1;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1+document.getElementById("D"+layers[a]).width;
                if(temp>right)right=temp;
                temp=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1;
                if(temp<left)left=temp;
             }
             right=(right+left)/2;
             for(var a=0;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.left=right-(document.getElementById("D"+layers[a]).width/2)+"px";
             }
        }else if(align==="gap"){
            var layers=getselectedlayers(),temp,right=document.getElementById("D"+layers[0]).style.left.slice(0,document.getElementById("D"+layers[0]).style.left.length-2)*1;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1;
                if(temp<right)right=temp;
             }
             document.getElementById("D"+layers[0]).style.left=right+"px";
             right+=document.getElementById("D"+layers[0]).width+document.getElementById("movetoolx").value*1;
             for(var a=1;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.left=right+"px";
                right+=document.getElementById("D"+layers[a]).width+document.getElementById("movetoolx").value*1;
             }
        }else{
            var layers=getselectedlayers(),temp,right=document.getElementById("D"+layers[0]).style.left.slice(0,document.getElementById("D"+layers[0]).style.left.length-2)*1;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1;
                if(temp<right)right=temp;
             }
             for(var a=0;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.left=right+"px";
             }
        }
    }else showmessage("Select multiple layers to align.")
}
function alignlayersvertical(align){
    if(ismultilayerselected()){    
        if(align==="top"){
            var layers=getselectedlayers(),temp,right=document.getElementById("D"+layers[0]).style.top.slice(0,document.getElementById("D"+layers[0]).style.top.length-2)*1;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1;
                if(temp<right)right=temp;
             }
             for(var a=0;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.top=right+"px";
             }
        }else if(align==="center"){
            var layers=getselectedlayers(),temp;
            var right=document.getElementById("D"+layers[0]).style.top.slice(0,document.getElementById("D"+layers[0]).style.top.length-2)*1+document.getElementById("D"+layers[0]).height;
            var left=document.getElementById("D"+layers[0]).style.top.slice(0,document.getElementById("D"+layers[0]).style.top.length-2)*1;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1+document.getElementById("D"+layers[a]).height;
                if(temp>right)right=temp;
                temp=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1;
                if(temp<left)left=temp;
             }
             right=(right+left)/2;
             for(var a=0;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.top=right-(document.getElementById("D"+layers[a]).height/2)+"px";
             }
        }else if(align==="gap"){
            var layers=getselectedlayers(),temp,right=document.getElementById("D"+layers[0]).style.top.slice(0,document.getElementById("D"+layers[0]).style.top.length-2)*1;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1;
                if(temp<right)right=temp;
             }
             document.getElementById("D"+layers[0]).style.top=right+"px";
             right+=document.getElementById("D"+layers[0]).height+document.getElementById("movetooly").value*1;
             for(var a=1;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.top=right+"px";
                right+=document.getElementById("D"+layers[a]).height+document.getElementById("movetooly").value*1;
             }
        }else{
            var layers=getselectedlayers(),temp,right=document.getElementById("D"+layers[0]).style.top.slice(0,document.getElementById("D"+layers[0]).style.top.length-2)*1+document.getElementById("D"+layers[0]).height;
            if(layers[layers.length-1]==="allselected") layers.pop();
            for(var a=1;a<layers.length;a++){
                temp=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1+document.getElementById("D"+layers[a]).height;
                if(temp>right)right=temp;
             }
             for(var a=0;a<layers.length;a++){
                document.getElementById("D"+layers[a]).style.top=right-document.getElementById("D"+layers[a]).height+"px";
             }
        }
    }else showmessage("Select multiple layers to align.")
}
// MOVE TOOL FUNCTIONS END //
function setcolor(){
    document.getElementById("colorf").style.backgroundColor=document.getElementById("forecolor").value;
    document.getElementById("colorb").style.backgroundColor=document.getElementById("backcolor").value;
}
function opencolorbox1(){
    document.getElementById("forecolor").click();
}
function opencolorbox2(){
    document.getElementById("backcolor").click();
}
function defaultcolor(){
    document.getElementById("backcolor").value="#000000";
    document.getElementById("forecolor").value="#ffffff";
    document.getElementById("colorf").style.backgroundColor=document.getElementById("forecolor").value;
    document.getElementById("colorb").style.backgroundColor=document.getElementById("backcolor").value;
}
function swapcolor(){
    var color=document.getElementById("backcolor").value;
    document.getElementById("backcolor").value=document.getElementById("forecolor").value;
    document.getElementById("forecolor").value=color;
    setcolor();
}
function activatetool(name){
    if(currenttool==="ttext"){
        document.getElementById("texttooldiv").classList.add("hide");
        document.getElementById("texttooloptions").classList.add("hide");
        document.getElementById("drawtextcheckmark").classList.add("hide");
        istexttoolboxactive=false;
    }
    if(currenttool==="tdrop" || currenttool==="tbucket" || currenttool==="ttext" || currenttool==="terase" || currenttool==="tbrush" || currenttool==="tcrop"){
        document.getElementById("doc"+currentdocument).style.cursor="default";
    }
    currenttool=name;
    deactivatetools();
    document.getElementById(currenttool).classList.add("activetool");
    if(currenttool==="tdrop"){
        document.getElementById("cursor").src="./public/img/eyedrop-outline.svg"
        document.querySelector("html").style.cursor="none";
        document.getElementById("doc"+currentdocument).style.cursor="none";
    }else if(currenttool==="ttext") {
        document.getElementById("texttooloptions").classList.remove("hide");
        document.getElementById("doc"+currentdocument).style.cursor="text";
    }else if(currenttool==="tbucket") {
        document.getElementById("cursor").src="./public/img/color-fill-outline.svg"
        document.querySelector("html").style.cursor="none";
        document.getElementById("doc"+currentdocument).style.cursor="none";
    }else if(currenttool==="tmove") document.getElementById("movetooloptions").classList.remove("hide");

}
function deactivatetools(){
    document.getElementById("movetooloptions").classList.add("hide");
    document.getElementById("cursor").classList.add("hide");
    document.querySelector("html").style.cursor="default";
    document.getElementById("tmove").classList.remove("activetool");
    document.getElementById("tbrush").classList.remove("activetool");
    document.getElementById("tshape").classList.remove("activetool");
    document.getElementById("ttext").classList.remove("activetool");
    document.getElementById("tcrop").classList.remove("activetool");
    document.getElementById("tdrop").classList.remove("activetool");
    document.getElementById("terase").classList.remove("activetool");
    document.getElementById("tbucket").classList.remove("activetool");
}
function changetextfont(source){
    if(source==="list"){document.getElementById("texttooloptionsfsizetext").value=document.getElementById("texttooloptionsfsize").value;
    }else{
        if(document.getElementById("texttooloptionsfsizetext").value===""){
            document.getElementById("texttooloptionsfsizetext").value="1";
            document.getElementById("texttooloptionsfsizetext").select();
        }
        else if(!(document.getElementById("texttooloptionsfsizetext").value*1>0)){
        document.getElementById("texttooloptionsfsizetext").value=document.getElementById("texttooloptionsfsize").value;
        document.getElementById("texttooloptionsfsizetext").select();
        }
    }
    document.getElementById("texttool").style.color=document.getElementById("texttoolcolor").value;
    document.getElementById("texttool").style.fontFamily=document.getElementById("texttooloptionsfont").value;
    document.getElementById("texttool").style.fontSize=document.getElementById("texttooloptionsfsizetext").value+"px";
    document.getElementById("texttoolcolorpicker").style.backgroundColor=document.getElementById("texttoolcolor").value;
}
function opentexttoolcolor(){
    document.getElementById("texttoolcolor").click();;
}
function drawtext(){
    istexttoolboxactive=false;
    var stringarray=[];
    var rows=0,cols=0;
    stringarray.push("");

if(document.getElementById("texttool").value.length>0){
    for(var a=0;a<document.getElementById("texttool").value.length;a++){
        if(document.getElementById("texttool").value.toString().charCodeAt(a)!=10){
            stringarray[rows]+=document.getElementById("texttool").value.toString().charAt(a);
        }else{
            if(cols<stringarray[rows].toString().length) cols=stringarray[rows].toString().length;
            stringarray.push("");
            rows+=1;
        }
    }
    
        if(cols<stringarray[rows].toString().length) cols=stringarray[rows].toString().length;
        newlayer();
        const canvas1=document.getElementById("drawingcanvas");
        const ctx1=canvas1.getContext("2d");
        document.getElementById("drawingcanvas").style.left=document.getElementById("texttool").offsetLeft-document.getElementById("doc"+currentdocument).offsetLeft+"px";
        document.getElementById("drawingcanvas").style.top=document.getElementById("texttool").offsetTop-document.getElementById("doc"+currentdocument).offsetTop+"px";
        document.getElementById("drawingcanvas").height=(rows+1)*document.getElementById("texttooloptionsfsizetext").value+rows;
        document.getElementById("drawingcanvas").width=(cols)*document.getElementById("texttooloptionsfsizetext").value;
        document.getElementById(currentlayer).width=document.getElementById("drawingcanvas").width;
        document.getElementById(currentlayer).height=document.getElementById("drawingcanvas").height;
        ctx1.font=document.getElementById("texttooloptionsfsizetext").value+"px "+document.getElementById("texttooloptionsfont").value;
        ctx1.fillStyle=document.getElementById("texttoolcolor").value;
        for(var a=0;a<=rows;a++) ctx1.fillText(stringarray[a],0,document.getElementById("texttooloptionsfsizetext").value*(a+1));

        trimimage();
        document.getElementById(currentlayer).src=document.getElementById("drawingcanvas").toDataURL("image/png");
    }
    document.getElementById("drawtextcheckmark").classList.add("hide");
    document.getElementById("texttooldiv").classList.add("hide");
}
//^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END
//^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END
//^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END
//^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END^^^^ TOOLS FUNCTIONS END

//****  LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START */
//****  LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START */
//****  LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START */
//****  LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START LAYER FUNCTIONS START */
function getcurrentlayer(){
    var count=0; var layer="none";
    const documentcurrent=document.getElementById("layerdock"+currentdocument).childNodes;
    for(var a=0;a<documentcurrent.length;a++){
            if(documentcurrent[a].classList.contains("activelayer")){
                count+=1;
                layer="D"+documentcurrent[a].id.slice(5,documentcurrent[a].id.length);
                if(count>1) {break;}
            }
        }
    if(count>1)return "multi";
    else return layer;
}
function selectlayer(layer){
    if(isctrldown){
        if(document.getElementById("layer"+layer).classList.contains("activelayer")){
            document.getElementById("layer"+layer).classList.remove("activelayer");
        }else document.getElementById("layer"+layer).classList.add("activelayer");
    }else {
        deselectlayers();
        document.getElementById("layer"+layer).classList.add("activelayer");
        currentlayer="D"+layer;
    }
}
function deselectlayers(){
    const documentcurrent=document.getElementById("layerdock"+currentdocument).childNodes;
    for(var a=0;a<documentcurrent.length;a++){
        documentcurrent[a].classList.remove("activelayer");
    }
}
function getselectedlayers(){
    var layers=[];
    var count=0;
    const documentcurrent=document.getElementById("layerdock"+currentdocument).childNodes;
    for(var a=documentcurrent.length-1;a>=0;a--){
            count+=1;
            if(documentcurrent[a].classList.contains("activelayer")){
                layers.push(documentcurrent[a].id.slice(5,documentcurrent[a].id.length));
            }
    }
    if(count===layers.length) layers.push("allselected");

    return layers;
}
function ismultilayerselected(){
    var count=0;
    const documentcurrent=document.getElementById("layerdock"+currentdocument).childNodes;
    for(var a=0;a<documentcurrent.length;a++){
            if(documentcurrent[a].classList.contains("activelayer")){
                count+=1;
                if(count>1) return true;
            }
    } return false;
}
function hidelayer(layer){
    if(document.getElementById("eye"+layer).src.toString().includes("eye.svg")){
        document.getElementById("D"+layer).classList.add("hide");
        document.getElementById("eye"+layer).src="./public/img/eye-off-sharp.svg";
    }else {
        document.getElementById("D"+layer).classList.remove("hide");
        document.getElementById("eye"+layer).src="./public/img/eye.svg";
    }
}
function islayereditable(layer){
    if(currentlayer==="none" || currentlayer==="multi") return false;
    if(islayerhidden(layer)) return false;
    else return true;
}
function islayerhidden(layer){
    if(document.getElementById("eye"+layer).src.toString().includes("eye.svg"))return false;
    else return true;
}
function deletelayer(){
    var layers=getselectedlayers();
    var a=0;
    if(layers[layers.length-1]==="allselected"){
        document.getElementById("layer"+layers[0]).classList.add("activelayer");
        currentlayer="D"+layers[0];
        a=1;
        for(;a<layers.length-1;a++){
            document.getElementById("layer"+layers[a]).remove();
            document.getElementById("D"+layers[a]).remove();
        }
    }else{
        for(;a<layers.length;a++){
            document.getElementById("layer"+layers[a]).remove();
            document.getElementById("D"+layers[a]).remove();
        }
        for(a=1;a<=DocumentsLayerCount[currentdocument];a++){
            if(document.getElementById("layer"+currentdocument+""+a)!=null){
                document.getElementById("layer"+currentdocument+""+a).classList.add("activelayer");
                currentlayer="D"+currentdocument+""+a;
                break;
            }
        }
    }
}
function settemplayer(object){
    templayer=object;
    islayermousedown=true;
}
function settempcanvas(object){
    tempcanvas=object;
}
function activatelayer(layer){
    if(!document.getElementById("layer"+layer).classList.contains("activelayer") && templayer===layer && islayermousedown){
        selectlayer(layer);
    }
}
function gettopmostactivelayer(){
    var layers=[];
    const documentcurrent=document.getElementById("layerdock"+currentdocument).childNodes;
    if(currentlayer==="none" || documentcurrent.length===1){ 
        layers.push(documentcurrent[0].id.slice(5,documentcurrent[0].id.length));
        layers.push(documentcurrent[0].id.slice(5,documentcurrent[0].id.length)); return layers;
    }
    for(var a=0;a<documentcurrent.length;a++){
            if(documentcurrent[a].classList.contains("activelayer")){ 
                layers.push(documentcurrent[a].id.slice(5,documentcurrent[a].id.length));
                if(a===0)layers.push(documentcurrent[a].id.slice(5,documentcurrent[a].id.length));
                else layers.push(documentcurrent[a].id.slice(5,documentcurrent[a].id.length));
                return layers;
            }
    }
}
function newlayer(){
    var layeractive=gettopmostactivelayer();
    deselectlayers();
    DocumentsLayerCount[currentdocument]+=1;
    var tmpstring="'"+"D"+currentdocument+""+DocumentsLayerCount[currentdocument]+"'";
    document.getElementById("doc"+currentdocument).innerHTML+="<img src='' draggable='false' class='canvass' id='D"+currentdocument+""+DocumentsLayerCount[currentdocument]+"' height='' width='' onmousemove="+String.fromCharCode(34)+"canvasmousemove(event,"+tmpstring+")"+String.fromCharCode(34)+" onmouseup="+String.fromCharCode(34)+"canvasmouseup(event,"+tmpstring+")"+String.fromCharCode(34)+" onmousedown="+String.fromCharCode(34)+"canvasmousedown(event,"+tmpstring+")"+String.fromCharCode(34)+"/>";
    document.getElementById("doc"+currentdocument).insertBefore(document.getElementById("D"+currentdocument+""+DocumentsLayerCount[currentdocument]),document.getElementById("D"+layeractive[1]));
    document.getElementById("doc"+currentdocument).insertBefore(document.getElementById("D"+layeractive[1]),document.getElementById("D"+currentdocument+""+DocumentsLayerCount[currentdocument]));
    tmpstring=currentdocument+""+DocumentsLayerCount[currentdocument];
    document.getElementById("layerdock"+currentdocument).innerHTML+="<div id='layer"+tmpstring+"' class='layer activelayer layerdrag' draggable='true' ondragleave='layerdragleave(event)' ondragover='layerdragover(event)' ondragstart='layerdragstart(event)' ondrop='layerdrop(event)'><div><img id='eye"+tmpstring+"' src='./public/img/eye.svg' onclick="+String.fromCharCode(34)+"hidelayer('"+tmpstring+"')"+String.fromCharCode(34)+" class='layereye layerdrag'></div><div><img id='preview"+tmpstring+"' src='' class='layerpreview layerdrag'></div><div id='name"+tmpstring+"' class='layername layerdrag' onmousemove="+String.fromCharCode(34)+"activatelayer('"+tmpstring+"')"+String.fromCharCode(34)+" onmousedown="+String.fromCharCode(34)+"settemplayer('"+tmpstring+"')"+String.fromCharCode(34)+" onmouseup="+String.fromCharCode(34)+"selectlayer('"+tmpstring+"')"+String.fromCharCode(34)+">Layer "+getnewlayername()+"</div></div>";
    document.getElementById("layerdock"+currentdocument).insertBefore(document.getElementById("layer"+tmpstring),document.getElementById("layer"+layeractive[0]));
    currentlayer="D"+tmpstring;
    //document.getElementById("D"+currentdocument+"1").getContext("2d").restore();9
}
function layerdrop(event){
    event.preventDefault();
    //const data = event.dataTransfer.getData("Text");
    document.getElementById("layer"+event.target.id.slice(event.target.id.indexOf(""+currentdocument+""),event.target.id.length)).style.setProperty("box-shadow","0 0");
    const layers=getselectedlayers();
    if(layers[layers.length]!="allselected")
    for(var a=(layers.length-1);a>=0;a--){
        document.getElementById("layerdock"+currentdocument).insertBefore(document.getElementById("layer"+layers[a]),document.getElementById("layer"+event.target.id.slice(event.target.id.indexOf(""+currentdocument+""),event.target.id.length)));
        document.getElementById("doc"+currentdocument).insertBefore(document.getElementById("D"+layers[a]),document.getElementById("D"+event.target.id.slice(event.target.id.indexOf(""+currentdocument+""),event.target.id.length)));
        document.getElementById("doc"+currentdocument).insertBefore(document.getElementById("D"+event.target.id.slice(event.target.id.indexOf(""+currentdocument+""),event.target.id.length)),document.getElementById("D"+layers[a]));
    }
}
function layerdragstart(event){
    event.dataTransfer.setData("Text",event.target.id);
}
function layerdragover(event){
    event.preventDefault();
    if(event.target!=undefined)
    if(event.target.matches(".layerdrag"))
    document.getElementById("layer"+event.target.id.slice(event.target.id.indexOf(""+currentdocument+""),event.target.id.length)).style.setProperty("box-shadow","0px 2px 10px black inset");
}
function layerdragleave(event){
    try{
    if(event.target!=undefined)
    if(event.target.matches(".layerdrag"))
    document.getElementById("layer"+event.target.id.slice(event.target.id.indexOf(""+currentdocument+""),event.target.id.length)).style.setProperty("box-shadow","0 0");
    }catch(err){
        //remove box shadow on layers if any 
        for(var a=1;a<=DocumentsLayerCount[currentdocument];a++){
            if(document.getElementById("layer"+currentdocument+""+a)!=null) document.getElementById("layer"+currentdocument+""+a).style.setProperty("box-shadow","0 0");
        }
        console.log("error:"+err);
    }
}
function getnewlayername(){
    var tmpstring;
    var layernum=1;
    const documentcurrent=document.getElementById("layerdock"+currentdocument).childNodes;
    for(var a=0;a<documentcurrent.length;a++){
            tmpstring=document.getElementById("name"+documentcurrent[a].id.slice(5,documentcurrent[a].id.length)).innerText;
            if(tmpstring.includes("Layer ")){
                tmpstring=tmpstring.slice(6,tmpstring.length);
                if(layernum<(tmpstring*1)) layernum=tmpstring*1;
            }
        
    }
    return (layernum+1);
}
function movelayercontent(x,y){
    iscanvasmoved=true;
    if(!ismultilayerselected()){
    document.getElementById(currentlayer).style.top=document.getElementById(currentlayer).style.top.slice(0,document.getElementById(currentlayer).style.top.length-2)*1+y+"px";
    document.getElementById(currentlayer).style.left=document.getElementById(currentlayer).style.left.slice(0,document.getElementById(currentlayer).style.left.length-2)*1+x+"px";
    }else{
        var layers=getselectedlayers();
        if(layers[layers.length-1]==="allselected") layers.pop();
        for(var a=0;a<layers.length;a++){
            document.getElementById("D"+layers[a]).style.top=document.getElementById("D"+layers[a]).style.top.slice(0,document.getElementById("D"+layers[a]).style.top.length-2)*1+y+"px";
            document.getElementById("D"+layers[a]).style.left=document.getElementById("D"+layers[a]).style.left.slice(0,document.getElementById("D"+layers[a]).style.left.length-2)*1+x+"px";
        }
    }
}
function linklayers(){
    var layers=getselectedlayers();
    if(layers[layers.length-1]==="allselected") layers.pop();
    if(layers.length>1){

    }else showmessage("Select multiple layers to link.");
}

//****  LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END */
//****  LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END */
//****  LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END */
//****  LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END LAYER FUNCTIONS END */

//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$
//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$
//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$
//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$

function keydown(event){
    console.log(event.key);
    if(event.ctrlKey)isctrldown=true;
    if(event.key==="ArrowUp")movelayercontent(0,-1);
    if(event.key==="ArrowDown")movelayercontent(0,1);
    if(event.key==="ArrowRight")movelayercontent(1,0);
    if(event.key==="ArrowLeft")movelayercontent(-1,0);
    if(event.key==="Escape"){
        if(currenttool==="ttext"){
            document.getElementById("texttooldiv").classList.add("hide");
            document.getElementById("texttooloptions").classList.add("hide");
            istexttoolboxactive=false;
        } 
    }
    if(!istexttoolboxactive){
        if(event.key==="v"){
            activatetool("tmove");
        }else if(event.key==="x"){defaultcolor();
        }else if(event.key==="Delete"){
            deletelayer();
        }else if(event.key===" "){
            if(!isspacebardown){ isspacebardown=true;
            if(!ismenushowing && !isdialogshowing) document.getElementById("doc"+currentdocument).style.cursor="grab";
            }
        }
    }
    if(currenttool==="tdrop"){
        activatetool("tmove");
    } 
}
function keyup(){
    if(isspacebardown){
         document.getElementById("doc"+currentdocument).style.cursor="default";
        isspacebardown=false;
    }
    isctrldown=false;
}
function showmessage(message){
    document.getElementById("message").innerText=message;
    if(document.getElementById("message").classList.contains("hide")){
    document.getElementById("message").classList.remove("hide");
    setTimeout(function(){
        document.getElementById("message").classList.add("hide");
    },2500);}
}

//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$
//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$
//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$
//  KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$ KEY EVENTS START $$$

function test(){
    const canvas1=drawingcanvas;
    const ctx1=document.getElementById("drawingcanvas").getContext("2d");
    ctx1.drawImage(document.getElementById("fullscreen"),0,0);//,document.getElementById("fullscreen").width,document.getElementById("fullscreen").height), 10, 10);
    document.getElementById(currentlayer).src=document.getElementById("drawingcanvas").toDataURL("image/png");
1    /* test 1 starts
    const documentcurrent=document.getElementById("doc"+currentdocument).childNodes;
    for(var a=0;a<documentcurrent.length;a++) console.log(documentcurrent[a].id)
const canvas1=document.getElementById(currentlayer);
const ctx1=canvas1.getContext("2d");
//document.getElementById(currentlayer).height=document.getElementById("svg01").height;
//document.getElementById(currentlayer).width=document.getElementById("svg01").width;
//var imagedata=ctx1.getImageData(0,0,canvas1.width,canvas1.height);
ctx1.putImageData(ctx1.getImageData(0,0,canvas1.width,canvas1.height),0,0);
ctx1.scale(2,2);
//ctx1.drawImage(document.getElementById("drawtextcheckmark"),0,0,500,500,0,0,200,100);

const img=document.createElement("img");
//console.log(canvas1.toDataURL("image/png"));
//ctx1.putImageData(ctx1.getImageData(img,0,0,img.width,img.height), 10, 10);

/*
const imgData = ctx1.createImageData(canvas1.width, canvas1.height);
for (let i = 0; i < imgData.data.length; i += 4)
  {
  if(imgData.data[i+3]>0){
  imgData.data[i+0] = 255;
  imgData.data[i+1] = 0;
  imgData.data[i+2] = 0;
  }
  }
ctx1.putImageData(imgData, 10, 10); *///test 1 ends
//trimimage(currentlayer);
//document.getElementById(currentlayer).src=document.getElementById("drawingcanvas").toDataURL("image/png");
}
function trimimage(canvaselement){
//trim image from all the corners
const canvas1=drawingcanvas;
const ctx1=canvas1.getContext("2d");
var imagedata=ctx1.getImageData(0,0,canvas1.width,canvas1.height);
var top=0,left=0,bottom=0,right=0,w=3,h;
var canvasleft,canvastop;
canvasleft=canvas1.style.left.slice(0,canvas1.style.left.length-2)*1;
canvastop=canvas1.style.top.slice(0,canvas1.style.top.length-2)*1;
    // calculating top
var istransparent=true;
    for(h=0;h<canvas1.height;h++){
        for(w=(h*4*canvas1.width)+3;w<=canvas1.width*4*(h+1);w+=4){
            if(imagedata.data[w]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) top+=1;
        else {break;}
    }

    if(top===canvas1.width)throw("empty canvas");
    // calculating bottom
    istransparent=true;
    for(h=(canvas1.height-1);h>=0;h--){
        for(w=(h*4*canvas1.width)+3;w<=canvas1.width*4*(h+1);w+=4){
            if(imagedata.data[w]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) bottom+=1;
        else {break;}
    }

    var idata=ctx1.getImageData(0,top,canvas1.width,(canvas1.height-top-bottom));
    canvas1.height=canvas1.height-top-bottom;
    ctx1.putImageData(idata,0,0);
    imagedata=ctx1.getImageData(0,0,canvas1.width,canvas1.height);
    //ctx1.scale(2,2);
    // calculating left
    istransparent=true;
    for(w=3;w<canvas1.width*4;w+=4){
        for(h=w;h<=(canvas1.width*4*(canvas1.height-1)+w);h+=(canvas1.width*4)){
            if(imagedata.data[h]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) left+=1;
        else {break;}
    }
    // calculating right
    istransparent=true;
    for(w=(canvas1.width*4-1);w>0;w-=4){
        for(h=w;h<=(canvas1.width*4*(canvas1.height-1)+w);h+=(canvas1.width*4)){
            if(imagedata.data[h]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) right+=1;
        else {break;}
    }

    idata=ctx1.getImageData(left,0,(canvas1.width-left-right),canvas1.height);
    canvas1.width=canvas1.width-left-right;
    ctx1.putImageData(idata,0,0);
    //ctx1.scale(2,2);
    canvas1.style.left=canvasleft+left+"px";
    canvas1.style.top=canvastop+top+"px";
    //console.log(imagedata.data.length/4)ps
    console.log("top="+top+"bottom="+bottom+"left="+left+"right="+right)

}
function trimimage1(canvaselement){
//trim image from all the corners
try{
const img1=document.getElementById(canvaselement);
const canvas1=document.createElement("canvas");
canvas1.width=img1.width;
canvas1.height=img1.height;
const ctx1=canvas1.getContext("2d");
ctx1.clearRect(0,0,img1.width,img1.height);
ctx1.drawImage(img1,0,0,img1.width,img1.height);
//document.getElementById("fullscreen").src=canvas1.toDataURL();
var imagedata=ctx1.getImageData(0,0,img1.width,img1.height);
var top=0,left=0,bottom=0,right=0,w=3,h;
var canvasleft,canvastop;
canvasleft=img1.style.left.slice(0,img1.style.left.length-2)*1;
canvastop=img1.style.top.slice(0,img1.style.top.length-2)*1;
    // calculating top
var istransparent=true;
    for(h=0;h<img1.height;h++){
        for(w=(h*4*img1.width)+3;w<=img1.width*4*(h+1);w+=4){
            if(imagedata.data[w]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) top+=1;
        else {break;}
    }

    if(top===img1.width)throw("empty canvas");
    // calculating bottom
    istransparent=true;
    for(h=(img1.height-1);h>=0;h--){
        for(w=(h*4*img1.width)+3;w<=img1.width*4*(h+1);w+=4){
            if(imagedata.data[w]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) bottom+=1;
        else {break;}
    }
    
    var idata=ctx1.getImageData(0,top,img1.width,(img1.height-top-bottom));
    canvas1.height=img1.height-top-bottom;
    ctx1.putImageData(idata,0,0);
    imagedata=ctx1.getImageData(0,0,canvas1.width,canvas1.height);
    
    //ctx1.scale(2,2);
    // calculating left
    istransparent=true;
    for(w=3;w<canvas1.width*4;w+=4){
        for(h=w;h<=(canvas1.width*4*(canvas1.height-1)+w);h+=(canvas1.width*4)){
            if(imagedata.data[h]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) left+=1;
        else {break;}
    }
    // calculating right
    istransparent=true;
    for(w=(canvas1.width*4-1);w>0;w-=4){
        for(h=w;h<=(canvas1.width*4*(canvas1.height-1)+w);h+=(canvas1.width*4)){
            if(imagedata.data[h]>0){
                istransparent=false; break;
            }
        }
        if(istransparent) right+=1;
        else {break;}
    }

    idata=ctx1.getImageData(left,0,(canvas1.width-left-right),canvas1.height);
    canvas1.width=img1.width-left-right;
    ctx1.putImageData(idata,0,0);
    
    img1.width=img1.width-left-right;
    img1.height=img1.height-top-bottom;
    img1.src=canvas1.toDataURL("image/png");
    img1.style.left=canvasleft+left+"px";
    img1.style.top=canvastop+top+"px";
    console.log("top="+top+"bottom="+bottom+"left="+left+"right="+right)
    }catch(error){
        console.log(error);
    }

}

/// *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** ///
/// *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** ///
/// *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** ///
/// *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** *** IMAGE MENU FUNCTIONS START *** ///
function showimagemenudialog(dialog){
    if(!ismultilayerselected() && islayereditable(currentlayer.slice(1,currentlayer.length))){
        if(dialog==="invert"){
            invertimage(); return;
        }
        const img=document.getElementById(currentlayer);
        imagepreview.width=img.width;
        imagepreview.height=img.height;
        var ctx=imagepreview.getContext("2d");
        ctx.drawImage(img,0,0,img.width,img.height);//,img.offsetLeft,img.offsetTop,img.width,img.height);
        //ctx.putImageData(document.getElementById(currentlayer).getContext("2d").getImageData(0,0,imagepreview.width,imagepreview.height),0,0);
        resetbrightnesscontrastslider();
        document.getElementById(dialog).classList.remove("hide");
    }else{
        showmessage("Layer not editable!");
    }
}
function hideimagemenudialog(dialog){
    //const canvas1=document.getElementById(currentlayer);
    //const ctx1=canvas1.getContext("2d");
    imagepreview.getContext("2d"); document.getElementById(currentlayer).src=imagepreview.toDataURL("image/png");
    //ctx1.putImageData(ctx2.getImageData(0,0,canvas1.width,canvas1.height),0,0);
    hidedialog(dialog);
}
function invertimage(){
    if(!ismultilayerselected() && islayereditable(currentlayer.slice(1,currentlayer.length))){
        const img=document.getElementById(currentlayer);
        imagepreview.width=img.width;
        imagepreview.height=img.height;
        var ctx=imagepreview.getContext("2d");
        ctx.drawImage(img,0,0,img.width,img.height);
        var imagedata=ctx.getImageData(0,0,imagepreview.width,imagepreview.height);
        for(var a=0;a<imagedata.data.length;a+=4){
            imagedata.data[a]=255-imagedata.data[a];
            imagedata.data[a+1]=255-imagedata.data[a+1];
            imagedata.data[a+2]=255-imagedata.data[a+2];
        }
       ctx.putImageData(imagedata,0,0);
       img.src=imagepreview.toDataURL("image/png");
    }
}
function brightnessimage(){
    const canvas1=document.createElement('canvas');
    const ctx1=canvas1.getContext("2d");
    const ctx2=imagepreview.getContext("2d");
    canvas1.width=imagepreview.width; canvas1.height=imagepreview.width;
    if(document.getElementById("brightnesscontrastpreviewcheckbox").checked){
        var imagedata=ctx2.getImageData(0,0,canvas1.width,canvas1.height);
        for(var a=0;a<imagedata.data.length;a+=4){
                imagedata.data[a]=imagedata.data[a]+document.getElementById("brightnessimageslider").value*1;
                imagedata.data[a+1]=imagedata.data[a+1]+document.getElementById("brightnessimageslider").value*1;
                imagedata.data[a+2]=imagedata.data[a+2]+document.getElementById("brightnessimageslider").value*1;
                if(imagedata.data[a]<0) imagedata.data[a]=0;
                else if(imagedata.data[a]>255) imagedata.data[a]=255;
                if(imagedata.data[a+1]<0) imagedata.data[a+1]=0;
                else if(imagedata.data[a+1]>255) imagedata.data[a+1]=255;
                if(imagedata.data[a+2]<0) imagedata.data[a+2]=0;
                else if(imagedata.data[a+2]>255) imagedata.data[a+2]=255;
        }
       ctx1.putImageData(imagedata,0,0);
    }else ctx1.putImageData(ctx2.getImageData(0,0,canvas1.width,canvas1.height),0,0);
    document.getElementById(currentlayer).src=canvas1.toDataURL("image/png");
}
function contrastimage(){
    const canvas1=document.createElement('canvas');
    const ctx1=canvas1.getContext("2d");
    const ctx2=imagepreview.getContext("2d");
    canvas1.width=imagepreview.width; canvas1.height=imagepreview.width;
    if(document.getElementById("brightnesscontrastpreviewcheckbox").checked){
        var imagedata=ctx2.getImageData(0,0,canvas1.width,canvas1.height); var max,min;
        for(var a=0;a<imagedata.data.length;a+=4){
                max=min=imagedata.data[a];
                if(max>imagedata.data[a+1])max=imagedata.data[a+1];if(max>imagedata.data[a+2])max=imagedata.data[a+2];
                if(min<imagedata.data[a+1])min=imagedata.data[a+1];if(min<imagedata.data[a+2])min=imagedata.data[a+2];
                max=(imagedata.data[a]/255)+(imagedata.data[a+1]/255)+(imagedata.data[a+2]/255);
                min=
                imagedata.data[a]=max;
                imagedata.data[a+1]=max;
                imagedata.data[a+2]=max;
        }
       ctx1.putImageData(imagedata,0,0);
    }else ctx1.putImageData(ctx2.getImageData(0,0,canvas1.width,canvas1.height),0,0);
    document.getElementById(currentlayer).src=canvas1.toDataURL("image/png");
}
function previewbrightnessimage(element){
    if(element==="brightnessimagetbox"){
        if(!(document.getElementById("brightnessimagetbox").value<100)){
            document.getElementById("brightnessimagetbox").value=0;
            document.getElementById("brightnessimagetbox").select();
        }    
    document.getElementById("brightnessimageslider").value=document.getElementById("brightnessimagetbox").value;
    }else document.getElementById("brightnessimagetbox").value=document.getElementById("brightnessimageslider").value;
    brightnessimage();
}
function previewcontrastimage(element){
    if(element==="contrastimagetbox"){
        if(!(document.getElementById("contrastimagetbox").value<150)){
            document.getElementById("contrastimagetbox").value=0;
            document.getElementById("contrastimagetbox").select();
        }    
    document.getElementById("contrastimageslider").value=document.getElementById("contrastimagetbox").value;
    }else document.getElementById("contrastimagetbox").value=document.getElementById("contrastimageslider").value;
    contrastimage();
}
function changebrightnesscontrast(){
        const ctx=imagepreview.getContext("2d");
        var imagedata=ctx.getImageData(0,0,imagepreview.width,imagepreview.height);
        for(var a=0;a<imagedata.data.length;a+=4){
            imagedata.data[a]=imagedata.data[a]+document.getElementById("brightnessimageslider").value*1;
            imagedata.data[a+1]=imagedata.data[a+1]+document.getElementById("brightnessimageslider").value*1;
            imagedata.data[a+2]=imagedata.data[a+2]+document.getElementById("brightnessimageslider").value*1;
            if(imagedata.data[a]<0) imagedata.data[a]=0;
            else if(imagedata.data[a]>255) imagedata.data[a]=255;
            if(imagedata.data[a+1]<0) imagedata.data[a+1]=0;
            else if(imagedata.data[a+1]>255) imagedata.data[a+1]=255;
            if(imagedata.data[a+2]<0) imagedata.data[a+2]=0;
            else if(imagedata.data[a+2]>255) imagedata.data[a+2]=255;
            }
       ctx.putImageData(imagedata,0,0);
       document.getElementById(currentlayer).src=imagepreview.toDataURL("image/png");
       hidedialog("brightnesscontrast");
}
function resetbrightnesscontrastslider(){
    document.getElementById("brightnessimageslider").value=0;
    document.getElementById("brightnessimagetbox").value=0;
    document.getElementById("contrastimageslider").value=0;
    document.getElementById("contrastimagetbox").value=0;
    brightnessimage();
}
function previewcolorbalanceimage(element){
    if(element==="colorbalancebluetbox"){
        if(!(document.getElementById("colorbalancebluetbox").value<100)){
        document.getElementById("colorbalancebluetbox").value=0;
        document.getElementById("colorbalancebluetbox").select();
        }    
        document.getElementById("colorbalanceblueslider").value=document.getElementById("colorbalancebluetbox").value;
    }else document.getElementById("colorbalancebluetbox").value=document.getElementById("colorbalanceblueslider").value;

    if(element==="colorbalancegreentbox"){
        if(!(document.getElementById("colorbalancegreentbox").value<100)){
        document.getElementById("colorbalancegreentbox").value=0;
        document.getElementById("colorbalancegreentbox").select();
        }    
        document.getElementById("colorbalancegreenslider").value=document.getElementById("colorbalancegreentbox").value;
    }else document.getElementById("colorbalancegreentbox").value=document.getElementById("colorbalancegreenslider").value;

    if(element==="colorbalanceredtbox"){
        if(!(document.getElementById("colorbalanceredtbox").value<100)){
        document.getElementById("colorbalanceredtbox").value=0;
        document.getElementById("colorbalanceredtbox").select();
        }    
        document.getElementById("colorbalanceredslider").value=document.getElementById("colorbalanceredtbox").value;
    }else document.getElementById("colorbalanceredtbox").value=document.getElementById("colorbalanceredslider").value;

    colorbalanceimage();
}
function colorbalanceimage(){
    const canvas1=document.createElement('canvas');
    const ctx1=canvas1.getContext("2d");
    const ctx2=imagepreview.getContext("2d");
    canvas1.width=imagepreview.width; canvas1.height=imagepreview.width;
    if(document.getElementById("colorbalancepreviewcheckbox").checked){
        var imagedata=ctx2.getImageData(0,0,canvas1.width,canvas1.height);
        for(var a=0;a<imagedata.data.length;a+=4){
                imagedata.data[a]=imagedata.data[a]+document.getElementById("colorbalanceredslider").value*1;
                imagedata.data[a+1]=imagedata.data[a+1]+document.getElementById("colorbalancegreenslider").value*1;
                imagedata.data[a+2]=imagedata.data[a+2]+document.getElementById("colorbalanceblueslider").value*1;
                if(imagedata.data[a]<0) imagedata.data[a]=0;
                else if(imagedata.data[a]>255) imagedata.data[a]=255;
                if(imagedata.data[a+1]<0) imagedata.data[a+1]=0;
                else if(imagedata.data[a+1]>255) imagedata.data[a+1]=255;
                if(imagedata.data[a+2]<0) imagedata.data[a+2]=0;
                else if(imagedata.data[a+2]>255) imagedata.data[a+2]=255;
        }
       ctx1.putImageData(imagedata,0,0);
    }else ctx1.putImageData(ctx2.getImageData(0,0,canvas1.width,canvas1.height),0,0);
    document.getElementById(currentlayer).src=canvas1.toDataURL("image/png");
}
function resetcolorbalanceslider(){
    document.getElementById("colorbalanceredslider").value=0;
    document.getElementById("colorbalanceredtbox").value=0;
    document.getElementById("colorbalancegreenslider").value=0;
    document.getElementById("colorbalancegreentbox").value=0;
    document.getElementById("colorbalanceblueslider").value=0;
    document.getElementById("colorbalancebluetbox").value=0;
    colorbalanceimage();
}
function changecolorbalance(){
    const ctx=imagepreview.getContext("2d");
    var imagedata=ctx.getImageData(0,0,imagepreview.width,imagepreview.height);
        for(var a=0;a<imagedata.data.length;a+=4){
                imagedata.data[a]=imagedata.data[a]+document.getElementById("colorbalanceredslider").value*1;
                imagedata.data[a+1]=imagedata.data[a+1]+document.getElementById("colorbalancegreenslider").value*1;
                imagedata.data[a+2]=imagedata.data[a+2]+document.getElementById("colorbalanceblueslider").value*1;
                if(imagedata.data[a]<0) imagedata.data[a]=0;
                else if(imagedata.data[a]>255) imagedata.data[a]=255;
                if(imagedata.data[a+1]<0) imagedata.data[a+1]=0;
                else if(imagedata.data[a+1]>255) imagedata.data[a+1]=255;
                if(imagedata.data[a+2]<0) imagedata.data[a+2]=0;
                else if(imagedata.data[a+2]>255) imagedata.data[a+2]=255;
        }
    ctx.putImageData(imagedata,0,0);
    document.getElementById(currentlayer).src=imagepreview.toDataURL("image/png");
    hidedialog("colorbalance");
}